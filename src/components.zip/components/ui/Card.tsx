import { CardProps } from '@/types/home';
import { cartVariants } from '../utils/viariants';
import { cn } from './utils';

export default function Card({ children, className, variant = 'default', onClick, ...props }: CardProps) {
  return (
    <div className={cn('rounded-2xl border', className, cartVariants[variant])} {...props}>
      {children}
    </div>
  );
}
