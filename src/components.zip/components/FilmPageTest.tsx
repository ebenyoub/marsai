import { useState } from 'react';
import FilmPopup from './FilmPopup';
import { MockFilm, mockFilms } from './utils/movieMock';

export default function FilmsPageTest() {
  const [selectedFilm, setSelectedFilm] = useState<MockFilm | null>(null);

  return (
    <div className="p-6">
      {mockFilms.map(film => (
        <button
          key={film.id}
          onClick={() => setSelectedFilm(film)}
          className="mb-2 rounded bg-purple-600 px-4 py-2 text-white"
        >
          Open {film.title}
        </button>
      ))}

      <FilmPopup film={selectedFilm} open={!!selectedFilm} onClose={() => setSelectedFilm(null)} />
    </div>
  );
}
